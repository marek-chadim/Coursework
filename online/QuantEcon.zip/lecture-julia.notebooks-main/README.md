# lecture-julia.notebooks

[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/QuantEcon/lecture-julia.notebooks/main)

Notebooks for https://julia.quantecon.org

- [Lecture source](https://github.com/QuantEcon/lecture-julia.myst)
- [README source code](https://github.com/QuantEcon/lecture-julia.myst/blob/main/_notebook_repo/README.md) 
